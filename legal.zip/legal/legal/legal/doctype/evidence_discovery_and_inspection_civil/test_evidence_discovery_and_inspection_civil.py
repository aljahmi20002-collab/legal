# Copyright (c) 2024, Frappe Technologies and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestEvidenceDiscoveryandInspectionCivil(FrappeTestCase):
	pass

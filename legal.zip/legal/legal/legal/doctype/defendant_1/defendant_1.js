// Copyright (c) 2024, Frappe Technologies and contributors
// For license information, please see license.txt

frappe.ui.form.on('Defendant 1', {
	// refresh: function(frm) {

	// }
});
